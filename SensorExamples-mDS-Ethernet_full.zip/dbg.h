#ifndef DEBUG_H
#define DEBUG_H

#include "nsdl_support.h"
#include "mbed.h"

//Debug is disabled by default
#define DEBUG 1

#if (DEBUG)
extern Serial pc;
#define NSDL_DEBUG(x, ...) pc.printf("[NSDL_DEBUG: %s:%d]" x "\r\n", __FILE__, __LINE__, ##__VA_ARGS__);
#else
#define NSDL_DEBUG(x, ...)
#endif

#endif