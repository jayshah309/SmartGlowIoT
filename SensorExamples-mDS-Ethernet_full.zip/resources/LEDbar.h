// Light resource implementation

#ifndef LEDBAR_H
#define LEDBAR_H

#include "nsdl_support.h"

int create_LEDbar_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
