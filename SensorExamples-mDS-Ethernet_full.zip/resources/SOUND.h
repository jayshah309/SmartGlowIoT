// IPSO Illuminance Sensor implementation

#ifndef SOUND_H
#define SOUND_H

#include "nsdl_support.h"

int create_SOUND_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
