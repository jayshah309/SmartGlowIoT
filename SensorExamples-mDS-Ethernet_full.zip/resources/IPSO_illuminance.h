// IPSO Illuminance Sensor implementation

#ifndef IPSO_ILLUM_H
#define IPSO_ILLUM_H

#include "nsdl_support.h"

int create_IPSO_illuminance_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
