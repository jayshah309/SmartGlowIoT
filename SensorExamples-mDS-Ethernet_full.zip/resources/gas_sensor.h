// IPSO Illuminance Sensor implementation

#ifndef GAS_SENSOR_H
#define GAS_SENSOR_H

#include "nsdl_support.h"

int create_gas_sensor_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
