// RGB LED Array resource implementation

#ifndef LED_ARRAY_H
#define LED_ARRAY_H

#include "nsdl_support.h"

int create_LED_array_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
