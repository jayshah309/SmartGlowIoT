// IPSO Illuminance Sensor implementation

#ifndef UV_H
#define UV_H

#include "nsdl_support.h"

int create_UV_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
