// IPSO Presence Sensor implementation

#ifndef IPSO_PRESENCE_H
#define IPSO_PRESENCE_H

#include "nsdl_support.h"

int create_IPSO_presence_resource(sn_nsdl_resource_info_s *resource_ptr);

#endif
